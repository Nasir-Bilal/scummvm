begin_section("CGE");
	add_person("Arnaud Boutonn&eacute;", "Strangerke", "");
	add_person("Paul Gilbert", "dreammaster", "");
end_section();
