begin_section("Blade Runner");
	add_person("Thanasis Antoniou", "Praetorian", "");
	add_person("Thomas Fach-Pedersen", "madmoose", "");
	add_person("Peter Kohaut", "peterkohaut", "");
	add_person("Eugene Sandulenko", "sev", "");
end_section();
